/*============================================================================
  File:     Insider_QS_Questions.sql

  SQL Server Versions: 2016+, Azure
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2021, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	Restore database
	*you may need to change the backup
	and restore locations
*/
USE [master]
GO

RESTORE DATABASE [WideWorldImporters] 
	FROM  DISK = N'C:\Backups\WideWorldImporters_Bits.bak' WITH  FILE = 1,  
	MOVE N'WWI_Primary' TO N'C:\Databases\WideWorldImporters\WideWorldImporters.mdf',  
	MOVE N'WWI_UserData' TO N'C:\Databases\WideWorldImporters\WideWorldImporters_UserData.ndf',  
	MOVE N'WWI_Log' TO N'C:\Databases\WideWorldImporters\WideWorldImporters.ldf',  
	NOUNLOAD,  REPLACE,  STATS = 5

GO


/*
	Enable QS and clear data
	NOTE: These are *NOT* settings recommended for Production
*/
ALTER DATABASE [WideWorldImporters] SET QUERY_STORE = ON;
GO

ALTER DATABASE [WideWorldImporters] SET QUERY_STORE (
	OPERATION_MODE = READ_WRITE, 
	DATA_FLUSH_INTERVAL_SECONDS = 60, 
	INTERVAL_LENGTH_MINUTES = 30, 
	QUERY_CAPTURE_MODE = ALL
	);
GO

ALTER DATABASE [WideWorldImporters] SET QUERY_STORE CLEAR;
GO


/*
	Q: Would Optimize for Adhoc workload help with the adhoc queries?	
	A: For the plan cache, yes, for Query Store, no.
*/
SELECT name, value_in_use
FROM sys.configurations
WHERE name LIKE 'optimize%'

SELECT 
	objtype AS [CacheType],
	COUNT_BIG(*) AS [Total Plans],
	SUM(CAST(size_in_bytes AS DECIMAL(18, 2))) / 1024 / 1024 AS [Total MBs],
	AVG(usecounts) AS [Avg Use Count],
	SUM(CAST((CASE WHEN usecounts = 1 THEN size_in_bytes
	ELSE 0
	END) AS DECIMAL(18, 2))) / 1024 / 1024 AS [Total MBs � USE Count 1],
	SUM(CASE WHEN usecounts = 1 THEN 1
	ELSE 0
	END) AS [Total Plans � USE Count 1]
FROM sys.dm_exec_cached_plans
GROUP BY objtype
ORDER BY [Total MBs � USE Count 1] DESC
GO
--1746.781250	22577
--188.806060	37620

SELECT COUNT(*) 
FROM WideWorldImporters.sys.query_store_query_text;
GO

SELECT COUNT(*) 
FROM WideWorldImporters.sys.query_store_query;
GO

SELECT COUNT(*) 
FROM WideWorldImporters.sys.query_store_plan;
GO

sp_configure 'optimize for ad hoc workloads', 1;
GO
RECONFIGURE;
GO

DBCC FREEPROCCACHE;
GO

/*
	Q: Do we need a specific compatability mode for Query Store?
	A: Nope!
	https://docs.microsoft.com/en-us/sql/relational-databases/performance/upgrade-dbcompat-using-qta?view=sql-server-ver15
*/



/*
	Q: The actual execution plan is not available in query store, right?
	A: True
*/
SELECT TOP 100 TRY_CAST(query_plan AS XML),*
FROM WideWorldImporters.sys.query_store_plan;
GO



/*
	Q: What are your thoughts about the QDS Toolbox query store mining procedures?
	A: It's amazing and I highly recommend it.
	https://github.com/channeladvisor/qdstoolbox
*/

