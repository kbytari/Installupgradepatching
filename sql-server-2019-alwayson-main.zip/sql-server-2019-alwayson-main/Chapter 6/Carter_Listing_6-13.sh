sudo ufw allow 2224/tcp
sudo ufw allow 3121/tcp
sudo ufw allow 21064/tcp
sudo ufw allow 5405/udp

sudo ufw allow 1433/tcp
sudo ufw allow 5022/tcp

sudo ufw reload 
