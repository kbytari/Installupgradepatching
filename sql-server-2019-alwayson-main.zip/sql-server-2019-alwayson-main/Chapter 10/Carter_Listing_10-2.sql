SELECT 
	FailureConditionLevel
	, HealthCheckTimeout
FROM sys.dm_os_cluster_properties ;
