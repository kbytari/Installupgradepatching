BACKUP DATABASE HR 
TO  DISK = N'C:\Backups\HR.bak' 
WITH NAME = N'HR-Full Database Backup' ;
GO
