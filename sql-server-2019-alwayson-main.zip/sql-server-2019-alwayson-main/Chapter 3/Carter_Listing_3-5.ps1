Import-Module FailoverClusters

Set-ClusterQuorum -CloudWitness -AccountName aoag3eds  -AccessKey +6lqzNKVpLnDZCrLA0Haz0W8VhoYdW2k==
